<!--

    Licensed to the Apache Software Foundation (ASF) under one
    or more contributor license agreements.  See the NOTICE file
    distributed with this work for additional information
    regarding copyright ownership.  The ASF licenses this file
    to you under the Apache License, Version 2.0 (the
    "License"); you may not use this file except in compliance
    with the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing,
    software distributed under the License is distributed on an
    "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, either express or implied.  See the License for the
    specific language governing permissions and limitations
    under the License.

-->

# Pinot (with StarTree extension) Quickstart on Kubernetes with Helm

## Prerequisite

- kubectl (<https://kubernetes.io/docs/tasks/tools/install-kubectl>)
- Helm (<https://helm.sh/docs/using_helm/#installing-helm>)
- Configure kubectl to connect to the Kubernetes cluster.
  - Skip to [Section: How to setup a Pinot (with StarTree extension) cluster for demo](#How to setup a Pinot (with StarTree extension) cluster for demo) if a k8s cluster is already setup.

## (Optional) Setup a Kubernetes cluster on Amazon Elastic Kubernetes Service (Amazon EKS)

### (Optional) Create a new k8s cluster on AWS EKS

- Install AWS CLI (<https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-install.html#install-tool-bundled>)
- Install AWS-IAM-AUTHENTICATOR (<https://docs.aws.amazon.com/eks/latest/userguide/install-aws-iam-authenticator.html>)
- Install eksctl (<https://docs.aws.amazon.com/eks/latest/userguide/eksctl.html#installing-eksctl>)

- Login to your AWS account.

```bash
aws configure
```

Note that environment variables `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` will override the aws configuration in file `~/.aws/credentials`.

- Create an EKS cluster

Please modify the parameters in the example command below:

```bash
eksctl create cluster \
--name pinot-quickstart \
--version 1.25 \
--region us-west-2 \
--nodegroup-name standard-workers \
--node-type t3.small \
--nodes 3 \
--nodes-min 3 \
--nodes-max 4 \
--node-ami auto
```

You may want to create multiple node pools and label them differently. StarTree pinot performs better if each Zookeeper/Pinot pod runs on its own k8s node.
```bash
eksctl create nodegroup \
--cluster <cluster-name> \
--name <nodegroup-name> \
--node-type <instance-type> \
--nodes <desired-node-count> \
--node-labels=<key1=value1,key2=value2,...> \
--nodes-min <min-node-count> \
--nodes-max <max-node-count> \
--node-ami auto
```

For k8s 1.23+ we need to run the following commands to allow the containers to provision their storage
```
eksctl utils associate-iam-oidc-provider --region=us-east-2 --cluster=pinot-quickstart --approve

eksctl create iamserviceaccount \
  --name ebs-csi-controller-sa \
  --namespace kube-system \
  --cluster pinot-quickstart \
  --attach-policy-arn arn:aws:iam::aws:policy/service-role/AmazonEBSCSIDriverPolicy \
  --approve \
  --role-only \
  --role-name AmazonEKS_EBS_CSI_DriverRole

eksctl create addon --name aws-ebs-csi-driver --cluster pinot-quickstart --service-account-role-arn arn:aws:iam::$(aws sts get-caller-identity --query Account --output text):role/AmazonEKS_EBS_CSI_DriverRole --force
```

You can monitor cluster status by command:

```bash
EKS_CLUSTER_NAME=pinot-quickstart
aws eks describe-cluster --name ${EKS_CLUSTER_NAME}
```

Once the cluster is in `ACTIVE` status, it's ready to be used.

### (Optional) How to connect to an existing cluster

Simply run below command to get the credential for the cluster you just created or your existing cluster.

```bash
EKS_CLUSTER_NAME=pinot-quickstart
aws eks update-kubeconfig --name ${EKS_CLUSTER_NAME}
```

To verify the connection, you can run

```bash
kubectl get nodes
```

## (Optional) Setup a Kubernetes cluster on Google Kubernetes Engine(GKE)

### (Optional) Create a new k8s cluster on GKE

- Google Cloud SDK (<https://cloud.google.com/sdk/install>)
- Enable Google Cloud Account and create a project, e.g. `pinot-demo`.
  - `pinot-demo` will be used as example value for `${GCLOUD_PROJECT}` variable in script example.
  - `pinot-demo@example.com` will be used as example value for `${GCLOUD_EMAIL}`.

Below script will:

- Create a gCloud cluster `pinot-quickstart`
- Request 2 servers of type `n1-standard-8` for demo.

Please fill both environment variables: `${GCLOUD_PROJECT}` and `${GCLOUD_EMAIL}` with your gcloud project and gcloud account email in below script.

```bash
GCLOUD_PROJECT=[your gcloud project name]
GCLOUD_EMAIL=[Your gcloud account email]
./setup_gke.sh
```

E.g.

```bash
GCLOUD_PROJECT=pinot-demo
GCLOUD_EMAIL=pinot-demo@example.com
./setup_gke.sh
```

### (Optional) How to connect to an existing GKE cluster

Simply run below command to get the credential for the cluster you just created or your existing cluster.
Please modify the Env variables `${GCLOUD_PROJECT}`, `${GCLOUD_ZONE}`, `${GCLOUD_CLUSTER}` accordingly in below script.

```bash
GCLOUD_PROJECT=pinot-demo
GCLOUD_ZONE=us-west1-b
GCLOUD_CLUSTER=pinot-quickstart
gcloud container clusters get-credentials ${GCLOUD_CLUSTER} --zone ${GCLOUD_ZONE} --project ${GCLOUD_PROJECT}
```

## (Optional) Setup a Kubernetes cluster on Microsoft Azure

### (Optional) Create a new k8s cluster on Azure

- Install Azure CLI (<https://docs.microsoft.com/en-us/cli/azure/install-azure-cli?view=azure-cli-latest>)
- Login to your Azure account.

```bash
az login
```

- Create Resource Group

```bash
AKS_RESOURCE_GROUP=pinot-demo
AKS_RESOURCE_GROUP_LOCATION=eastus
az group create --name ${AKS_RESOURCE_GROUP} --location ${AKS_RESOURCE_GROUP_LOCATION}
```

- Create an AKS cluster

```bash
AKS_RESOURCE_GROUP=pinot-demo
AKS_CLUSTER_NAME=pinot-quickstart
az aks create --resource-group ${AKS_RESOURCE_GROUP}  --name ${AKS_CLUSTER_NAME} --node-count 3
```

(Optional) Please register default provider if above command failed for error: `MissingSubscriptionRegistration`

```bash
az provider register --namespace Microsoft.Network
```

### (Optional) How to connect to an existing AKS cluster

Simply run below command to get the credential for the cluster you just created or your existing cluster.

```bash
AKS_RESOURCE_GROUP=pinot-demo
AKS_CLUSTER_NAME=pinot-quickstart
az aks get-credentials --resource-group ${AKS_RESOURCE_GROUP} --name ${AKS_CLUSTER_NAME}
```

To verify the connection, you can run

```bash
kubectl get nodes
```

## How to setup a Pinot (with StarTree extension) cluster for demo

### Update helm dependency

```bash
helm dependency update
```

### Start Pinot (with StarTree extension) using Helm

```bash
kubectl create ns pinot-quickstart

# Create docker image pull secret for pinot (with StarTree extension) docker image
# If you are using docker hub, you can skip this step
kubectl create secret docker-registry startree-artifact \
  --docker-server=<startree-docker-registry> \
  --docker-username=<your-startree-username> \
  --docker-password=<your-startree-password> \
  -n pinot-quickstart

# First run dry-run with debug to verify (need to create the override.yaml file):
helm install -n pinot-quickstart pinot . --dry-run --debug --values override.yaml

# Install the Helm chart with (need to create the override.yaml file):
helm install -n pinot-quickstart pinot . --values override.yaml
```

### Pinot (with StarTree extension) Realtime QuickStart

#### Bring up a Kafka Cluster for realtime data ingestion

```bash
helm repo add incubator https://charts.helm.sh/incubator
helm install -n pinot-quickstart kafka incubator/kafka --set replicas=1
```

#### Create Kafka topic

```bash
kubectl -n pinot-quickstart exec kafka-0 -- kafka-topics.sh --bootstrap-server kafka-0:9092 --topic flights-realtime --create --partitions 1 --replication-factor 1
kubectl -n pinot-quickstart exec kafka-0 -- kafka-topics.sh --bootstrap-server kafka-0:9092 --topic flights-realtime-avro --create --partitions 1 --replication-factor 1
```

#### Load data into Kafka and create Pinot (with StarTree extension) schema/table

```bash
kubectl apply -f pinot-realtime-quickstart.yml
```

### How to query pinot (with StarTree extension) data

Please use below script to do local port-forwarding and open Pinot (with StarTree extension) query console on your web browser.

```bash
./query-pinot-data.sh
```

## Configuring the Chart

This chart includes a ZooKeeper chart as a dependency to the Pinot (with StarTree extension)
cluster in its `requirement.yaml` by default. The chart can be customized using the
following configurable parameters:

| Parameter                                        | Description                                                                                                                                                                  | Default                                                                                                                                                                                                                |
| ------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `image.repository`                               | Pinot (with StarTree extension) Container image repo                                                                                                                                                   | `apachepinot/pinot`                                                                                                                                                                                                    |
| `image.tag`                                      | Pinot (with StarTree extension) Container image tag                                                                                                                                                    | `release-0.7.1`                                                                                                                                                                                                        |
| `image.pullPolicy`                               | Pinot (with StarTree extension) Container image pull policy                                                                                                                                            | `IfNotPresent`                                                                                                                                                                                                         |
| `cluster.name`                                   | Pinot (with StarTree extension) Cluster name                                                                                                                                                           | `pinot-quickstart`                                                                                                                                                                                                     |
| ------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------                                                                                                                                                   |
| `controller.name`                                | Name of Pinot (with StarTree extension) Controller                                                                                                                                                     | `controller`                                                                                                                                                                                                           |
| `controller.port`                                | Pinot (with StarTree extension) controller port                                                                                                                                                        | `9000`                                                                                                                                                                                                                 |
| `controller.replicaCount`                        | Pinot (with StarTree extension) controller replicas                                                                                                                                                    | `1`                                                                                                                                                                                                                    |
| `controller.data.dir`                            | Pinot (with StarTree extension) controller data directory, should be same as `controller.persistence.mountPath` or a sub directory of it                                                               | `/var/pinot/controller/data`                                                                                                                                                                                           |
| `controller.vip.enabled`                         | Enable Pinot (with StarTree extension) controller Vip host                                                                                                                                             | `false`                                                                                                                                                                                                                |
| `controller.vip.host`                            | Pinot (with StarTree extension) controller Vip host                                                                                                                                                    | `pinot-controller`                                                                                                                                                                                                     |
| `controller.vip.port`                            | Pinot (with StarTree extension) controller Vip port                                                                                                                                                    | `9000`                                                                                                                                                                                                                 |
| `controller.persistence.enabled`                 | Use a PVC to persist Pinot (with StarTree extension) Controller data                                                                                                                                   | `true`                                                                                                                                                                                                                 |
| `controller.persistence.accessMode`              | Access mode of data volume                                                                                                                                                   | `ReadWriteOnce`                                                                                                                                                                                                        |
| `controller.persistence.size`                    | Size of data volume                                                                                                                                                          | `1G`                                                                                                                                                                                                                   |
| `controller.persistence.mountPath`               | Mount path of controller data volume                                                                                                                                         | `/var/pinot/controller/data`                                                                                                                                                                                           |
| `controller.persistence.storageClass`            | Storage class of backing PVC                                                                                                                                                 | `""`                                                                                                                                                                                                                   |
| `controller.jvmOpts`                             | Pinot (with StarTree extension) Controller JVM Options                                                                                                                                                 | `-Xms256M -Xmx1G -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -Xlog:gc+age*,safepoint:file=/home/pinot/gc-pinot-controller.log:time,level,tags:filecount=5,filesize=100M  -XX:NativeMemoryTracking=summary -XX:+AlwaysPreTouch -XX:+UseLargePages -XX:+CrashOnOutOfMemoryError -Djute.maxbuffer=4194304` |
| `controller.log4j2ConfFile`                      | Pinot (with StarTree extension) Controller log4j2 configuration file                                                                                                                                   | `/home/pinot/conf/log4j2.xml`                                                                                                                                                                                           |
| `controller.pluginsDir`                          | Pinot (with StarTree extension) Controller plugins directory                                                                                                                                           | `/home/pinot/plugins`                                                                                                                                                                                                   |
| `controller.service.port`                        | Service Port                                                                                                                                                                 | `9000`                                                                                                                                                                                                                 |
| `controller.external.enabled`                    | If True, exposes Pinot (with StarTree extension) Controller externally                                                                                                                                 | `true`                                                                                                                                                                                                                 |
| `controller.external.type`                       | Service Type                                                                                                                                                                 | `LoadBalancer`                                                                                                                                                                                                         |
| `controller.external.port`                       | Service Port                                                                                                                                                                 | `9000`                                                                                                                                                                                                                 |
| `controller.resources`                           | Pinot (with StarTree extension) Controller resource requests and limits                                                                                                                                | `{}`                                                                                                                                                                                                                   |
| `controller.nodeSelector`                        | Node labels for controller pod assignment                                                                                                                                    | `{}`                                                                                                                                                                                                                   |
| `controller.affinity`                            | Defines affinities and anti-affinities for pods as defined in: <https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity> preferences   | `{}`                                                                                                                                                                                                                   |
| `controller.tolerations`                         | List of node tolerations for the pods. <https://kubernetes.io/docs/concepts/configuration/taint-and-toleration/>                                                             | `[]`                                                                                                                                                                                                                   |
| `controller.podAnnotations`                      | Annotations to be added to controller pod                                                                                                                                    | `{}`                                                                                                                                                                                                                   |
| `controller.updateStrategy.type`                 | StatefulSet update strategy to use.                                                                                                                                          | `RollingUpdate`                                                                                                                                                                                                        |
| `controller.extra.configs`                       | Extra configs append to 'pinot-controller.conf' file to start Pinot (with StarTree extension) Controller                                                                                               | `pinot.set.instance.id.to.hostname=true`                                                                                                                                                                               |
| ------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------                                                                                                                                                   |
| `broker.name`                                    | Name of Pinot (with StarTree extension) Broker                                                                                                                                                         | `broker`                                                                                                                                                                                                               |
| `broker.port`                                    | Pinot (with StarTree extension) port                                                                                                                                                            | `8099`                                                                                                                                                                                                                 |
| `broker.replicaCount`                            | Pinot (with StarTree extension) broker replicas                                                                                                                                                        | `1`                                                                                                                                                                                                                    |
| `broker.jvmOpts`                                 | Pinot (with StarTree extension) Broker JVM Options                                                                                                                                                     | `-Xms256M -Xmx1G -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -Xlog:gc+age*,safepoint:file=/home/pinot/gc-pinot-broker.log:time,level,tags:filecount=5,filesize=100M -XX:NativeMemoryTracking=summary -XX:+AlwaysPreTouch -XX:+UseLargePages -XX:+CrashOnOutOfMemoryError -Djute.maxbuffer=4194304`     |
| `broker.log4j2ConfFile`                          | Pinot (with StarTree extension) Broker log4j2 configuration file                                                                                                                                       | `/home/pinot/conf/log4j2.xml`                                                                                                                                                                                           |
| `broker.pluginsDir`                              | Pinot (with StarTree extension) Broker plugins directory                                                                                                                                               | `/home/pinot/plugins`                                                                                                                                                                                                   |
| `broker.service.port`                            | Service Port                                                                                                                                                                 | `8099`                                                                                                                                                                                                                 |
| `broker.external.enabled`                        | If True, exposes Pinot (with StarTree extension) Broker externally                                                                                                                                     | `true`                                                                                                                                                                                                                 |
| `broker.external.type`                           | External service Type                                                                                                                                                        | `LoadBalancer`                                                                                                                                                                                                         |
| `broker.external.port`                           | External service Port                                                                                                                                                        | `8099`                                                                                                                                                                                                                 |
| `broker.routingTable.builderClass`               | Routing Table Builder Class                                                                                                                                                  | `random`                                                                                                                                                                                                               |
| `broker.resources`                               | Pinot (with StarTree extension) Broker resource requests and limits                                                                                                                                    | `{}`                                                                                                                                                                                                                   |
| `broker.nodeSelector`                            | Node labels for broker pod assignment                                                                                                                                        | `{}`                                                                                                                                                                                                                   |
| `broker.affinity`                                | Defines affinities and anti-affinities for pods as defined in: <https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity> preferences   | `{}`                                                                                                                                                                                                                   |
| `broker.tolerations`                             | List of node tolerations for the pods. <https://kubernetes.io/docs/concepts/configuration/taint-and-toleration/>                                                             | `[]`                                                                                                                                                                                                                   |
| `broker.podAnnotations`                          | Annotations to be added to broker pod                                                                                                                                        | `{}`                                                                                                                                                                                                                   |
| `broker.updateStrategy.type`                     | StatefulSet update strategy to use.                                                                                                                                          | `RollingUpdate`                                                                                                                                                                                                        |
| `broker.extra.configs`                           | Extra configs append to 'pinot-broker.conf' file to start Pinot (with StarTree extension) Broker                                                                                                       | `pinot.set.instance.id.to.hostname=true`                                                                                                                                                                               |
| ------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------                                                                                                                                                   |
| `server.name`                                    | Name of Pinot (with StarTree extension) Server                                                                                                                                                         | `server`                                                                                                                                                                                                               |
| `server.port.netty`                              | Pinot (with StarTree extension) server netty port                                                                                                                                                      | `8098`                                                                                                                                                                                                                 |
| `server.port.admin`                              | Pinot (with StarTree extension) server admin port                                                                                                                                                      | `8097`                                                                                                                                                                                                                 |
| `server.replicaCount`                            | Pinot (with StarTree extension) server replicas                                                                                                                                                        | `1`                                                                                                                                                                                                                    |
| `server.dataDir`                                 | Pinot (with StarTree extension) server data directory, should be same as `server.persistence.mountPath` or a sub directory of it                                                                       | `/var/pinot/server/data/index`                                                                                                                                                                                         |
| `server.segmentTarDir`                           | Pinot (with StarTree extension) server segment directory, should be same as `server.persistence.mountPath` or a sub directory of it                                                                    | `/var/pinot/server/data/segments`                                                                                                                                                                                      |
| `server.persistence.enabled`                     | Use a PVC to persist Pinot (with StarTree extension) Server data                                                                                                                                       | `true`                                                                                                                                                                                                                 |
| `server.persistence.accessMode`                  | Access mode of data volume                                                                                                                                                   | `ReadWriteOnce`                                                                                                                                                                                                        |
| `server.persistence.size`                        | Size of data volume                                                                                                                                                          | `4G`                                                                                                                                                                                                                   |
| `server.persistence.mountPath`                   | Mount path of server data volume                                                                                                                                             | `/var/pinot/server/data`                                                                                                                                                                                               |
| `server.persistence.storageClass`                | Storage class of backing PVC                                                                                                                                                 | `""`                                                                                                                                                                                                                   |
| `server.jvmOpts`                                 | Pinot (with StarTree extension) Server JVM Options                                                                                                                                                     | `-Xms512M -Xmx1G -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -Xlog:gc+age*,safepoint:file=/home/pinot/gc-pinot-server.log:time,level,tags:filecount=5,filesize=100M -XX:NativeMemoryTracking=summary -XX:+AlwaysPreTouch -XX:+UseLargePages -XX:+CrashOnOutOfMemoryError -Djute.maxbuffer=4194304`     |
| `server.log4j2ConfFile`                          | Pinot (with StarTree extension) Server log4j2 configuration file                                                                                                                                       | `/home/pinot/conf/log4j2.xml`                                                                                                                                                                                           |
| `server.pluginsDir`                              | Pinot (with StarTree extension) Server plugins directory                                                                                                                                               | `/home/pinot/plugins`                                                                                                                                                                                                   |
| `server.service.port`                            | Service Port                                                                                                                                                                 | `8098`                                                                                                                                                                                                                 |
| `server.resources`                               | Pinot (with StarTree extension) Server resource requests and limits                                                                                                                                    | `{}`                                                                                                                                                                                                                   |
| `server.nodeSelector`                            | Node labels for server pod assignment                                                                                                                                        | `{}`                                                                                                                                                                                                                   |
| `server.affinity`                                | Defines affinities and anti-affinities for pods as defined in: <https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity> preferences   | `{}`                                                                                                                                                                                                                   |
| `server.tolerations`                             | List of node tolerations for the pods. <https://kubernetes.io/docs/concepts/configuration/taint-and-toleration/>                                                             | `[]`                                                                                                                                                                                                                   |
| `server.podAnnotations`                          | Annotations to be added to server pod                                                                                                                                        | `{}`                                                                                                                                                                                                                   |
| `server.updateStrategy.type`                     | StatefulSet update strategy to use.                                                                                                                                          | `RollingUpdate`                                                                                                                                                                                                        |
| `server.extra.configs`                           | Extra configs append to 'pinot-server.conf' file to start Pinot (with StarTree extension) Server                                                                                                       | `pinot.set.instance.id.to.hostname=true`                                                                                                                                                                               |
| ------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------                                                                                                                                                   |
| `minion.name`                                    | Name of Pinot (with StarTree extension) Minion                                                                                                                                                         | `minion`                                                                                                                                                                                                               |
| `minion.port`                                    | Pinot (with StarTree extension) minion netty port                                                                                                                                                      | `9514`                                                                                                                                                                                                                 |
| `minion.replicaCount`                            | Pinot (with StarTree extension) minion replicas                                                                                                                                                        | `1`                                                                                                                                                                                                                    |
| `minion.dataDir`                                 | Pinot (with StarTree extension) minion data directory, should be same as `minion.persistence.mountPath` or a sub directory of it                                                                       | `/var/pinot/minion/data`                                                                                                                                                                                               |
| `minion.persistence.enabled`                     | Use a PVC to persist Pinot (with StarTree extension) minion data                                                                                                                                       | `true`                                                                                                                                                                                                                 |
| `minion.persistence.accessMode`                  | Access mode of data volume                                                                                                                                                   | `ReadWriteOnce`                                                                                                                                                                                                        |
| `minion.persistence.size`                        | Size of data volume                                                                                                                                                          | `4G`                                                                                                                                                                                                                   |
| `minion.persistence.mountPath`                   | Mount path of minion data volume                                                                                                                                             | `/var/pinot/minion/data`                                                                                                                                                                                               |
| `minion.persistence.storageClass`                | Storage class of backing PVC                                                                                                                                                 | `""`                                                                                                                                                                                                                   |
| `minion.jvmOpts`                                 | Pinot (with StarTree extension) minion JVM Options                                                                                                                                                     | `-Xms256M -Xmx1G -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -Xlog:gc+age*,safepoint:file=/home/pinot/gc-pinot-minion.log:time,level,tags:filecount=5,filesize=100M -XX:NativeMemoryTracking=summary -XX:+AlwaysPreTouch -XX:+UseLargePages -XX:+CrashOnOutOfMemoryError -Djute.maxbuffer=4194304`     |
| `minion.log4j2ConfFile`                          | Pinot minion log4j2 configuration file                                                                                                                                       | `/home/pinot/conf/log4j2.xml`                                                                                                                                                                                           |
| `minion.pluginsDir`                              | Pinot (with StarTree extension) minion plugins directory                                                                                                                                               | `/home/pinot/plugins`                                                                                                                                                                                                   |
| `minion.service.port`                            | Service Port                                                                                                                                                                 | `9514`                                                                                                                                                                                                                 |
| `minion.resources`                               | Pinot (with StarTree extension) minion resource requests and limits                                                                                                                                    | `{}`                                                                                                                                                                                                                   |
| `minion.nodeSelector`                            | Node labels for minion pod assignment                                                                                                                                        | `{}`                                                                                                                                                                                                                   |
| `minion.affinity`                                | Defines affinities and anti-affinities for pods as defined in: <https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity> preferences   | `{}`                                                                                                                                                                                                                   |
| `minion.tolerations`                             | List of node tolerations for the pods. <https://kubernetes.io/docs/concepts/configuration/taint-and-toleration/>                                                             | `[]`                                                                                                                                                                                                                   |
| `minion.podAnnotations`                          | Annotations to be added to minion pod                                                                                                                                        | `{}`                                                                                                                                                                                                                   |
| `minion.updateStrategy.type`                     | StatefulSet update strategy to use.                                                                                                                                          | `RollingUpdate`                                                                                                                                                                                                        |
| `minion.extra.configs`                           | Extra configs append to 'pinot-minion.conf' file to start Pinot (with StarTree extension) Minion                                                                                                       | `pinot.set.instance.id.to.hostname=true`                                                                                                                                                                               |
| ------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------                                                                                                                                                   |
| `zookeeper.enabled`                              | If True, installs Zookeeper Chart                                                                                                                                            | `true`                                                                                                                                                                                                                 |
| `zookeeper.resources`                            | Zookeeper resource requests and limits                                                                                                                                       | `{}`                                                                                                                                                                                                                   |
| `zookeeper.env`                                  | Environmental variables provided to Zookeeper Zookeeper                                                                                                                      | `{ZK_HEAP_SIZE: "256M"}`                                                                                                                                                                                               |
| `zookeeper.storage`                              | Zookeeper Persistent volume size                                                                                                                                             | `2Gi`                                                                                                                                                                                                                  |
| `zookeeper.image.tag`                            | Zookeeper Image Version                                                                                                                                                      |
| `zookeeper.image.PullPolicy`                     | Zookeeper Container pull policy                                                                                                                                              | `IfNotPresent`                                                                                                                                                                                                         |
| `zookeeper.url`                                  | URL of Zookeeper Cluster (unneeded if installing Zookeeper Chart)                                                                                                            | `""`                                                                                                                                                                                                                   |
| `zookeeper.port`                                 | Port of Zookeeper Cluster                                                                                                                                                    | `2181`                                                                                                                                                                                                                 |
| `zookeeper.affinity`                             | Defines affinities and anti-affinities for pods as defined in: <https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity> preferences   | `{}`                                                                                                                                                                                                                   |
| ------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------                                                                                                                                                   |

Specify parameters using `--set key=value[,key=value]` argument to `helm install`

```bash
helm install --name pinot -f override.yaml . --set server.replicaCount=2
```

Alternatively a YAML file that specifies the values for the parameters can be provided like this:

```bash
helm install --name pinot -f override.yaml .
```

For example, if you want to configure s3 as Pinot deep store, the override.yaml files should contain the following
```
controller:
  data:
    dir: <s3 path>
  extra:
    configs: |-
      pinot.set.instance.id.to.hostname=true
      controller.task.scheduler.enabled=true
      pinot.controller.segment.fetcher.protocols=s3
      pinot.controller.segment.fetcher.s3.class=org.apache.pinot.common.utils.fetcher.PinotFSSegmentFetcher
      pinot.controller.storage.factory.class.s3=org.apache.pinot.plugin.filesystem.S3PinotFS
      pinot.controller.storage.factory.s3.region=<aws region>
      # the following two are needed if the node does not have access to s3
      pinot.controller.storage.factory.s3.accessKey=<aws access key>
      pinot.controller.storage.factory.s3.secretKey=<aws secret key>
server:
  extra:
    configs: |-
      pinot.set.instance.id.to.hostname=true
      pinot.server.instance.realtime.alloc.offheap=true
      pinot.server.segment.fetcher.protocols=s3
      pinot.server.segment.fetcher.s3.class=org.apache.pinot.common.utils.fetcher.PinotFSSegmentFetcher
      pinot.server.storage.factory.class.s3=org.apache.pinot.plugin.filesystem.S3PinotFS
      pinot.server.storage.factory.s3.region=<aws region>
      # the following two are needed if the node does not have access to s3
      pinot.server.storage.factory.s3.accessKey=<aws access key>
      pinot.server.storage.factory.s3.secretKey=<aws secret key>
minioin:
  extra:
    configs: |-
      pinot.set.instance.id.to.hostname=true
      pinot.minion.segment.fetcher.protocols=s3
      pinot.minion.segment.fetcher.s3.class=org.apache.pinot.common.utils.fetcher.PinotFSSegmentFetcher
      pinot.minion.storage.factory.class.s3=org.apache.pinot.plugin.filesystem.S3PinotFS
      pinot.minion.storage.factory.s3.region=<aws region>
      # the following two are needed if the node does not have access to s3
      pinot.minion.storage.factory.s3.accessKey=<aws access key>
      pinot.minion.storage.factory.s3.secretKey=<aws secret key>
```

If you are using GKE, Create a storageClass:

```
kubectl apply -f gke-ssd.yaml
```

or If you want to use pd-standard storageClass:

```bash
kubectl apply -f gke-pd.yaml
```

## How to clean up Pinot (with StarTree extension) deployment

```bash
kubectl delete ns pinot-quickstart
```

### Common Fields to Override
When deploying a Pinot cluster, you may want to tune the following prarameters
- startree pinot cluster name
- startree pinot image
- replicas of each pinot components
- persistent disk size
- node pools
- compute resources: CPU, memory, jvm 

```
# tune the cluster name
cluster:
  name: pinot

# tune the pinot image
image:
  repository: repo.startreedata.io/external-docker-registry-<customer-name>/startree-pinot
  tag: 1.0.0-ST.19 # or some other versions that are available to Atlassian

zookeeper:
  # replica
  replicaCount: 1
  # persistent disk
  storage: 20Gi
  # normally, we want to run each pinot component in its own node pool. we need to create different node pools 
  nodeSelector:
    key: value
  # cpu and memory: the should be close to the resource available in the selected node pool
  resources:
    requests:
      cpu: 4
      memory: "8Gi"
    limits:
      cpu: 4
      memory: "8Gi"
  # heap size: we typically use 2G
  env:
    ZK_HEAP_SIZE: "2G"
  

controller:
  # replica
  replicaCount: 1
  # persistent disk
  persistence:
    enabled: true
    size: 500Gi
  # normally, we want to run each pinot component in its own node pool. we need to create different node pools 
  nodeSelector:
    key: value
  # cpu and memory: the should be close to the resource available in the selected node pool
  resources:
    requests:
      cpu: 4
      memory: "8Gi"
    limits:
      cpu: 4
      memory: "8Gi"
  # jvm: notice that xmx and xms are usually set to be half of total memory
  jvmOpts: "-Xms4G -Xmx4G -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -Xlog:gc+age*,safepoint:file=/home/pinot/gc-pinot-controller.log:time,level,tags:filecount=5,filesize=100M -XX:NativeMemoryTracking=summary -XX:+AlwaysPreTouch -XX:+UseLargePages -XX:+CrashOnOutOfMemoryError -Djute.maxbuffer=4194304"

broker:
  # replica
  replicaCount: 1
  # persistent disk
  persistence:
    enabled: true
    size: 100Gi
    mountPath: /var/pinot/broker/data
  # normally, we want to run each pinot component in its own node pool. we need to create different node pools 
  nodeSelector:
    key: value
  # cpu and memory: the should be close to the resource available in the selected node pool
  resources:
    requests:
      cpu: 4
      memory: "8Gi"
    limits:
      cpu: 4
      memory: "8Gi"
  # jvm: notice that xmx and xms are usually set to be half of total memory
  jvmOpts: "-Xms4G -Xmx4G -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -Xlog:gc+age*,safepoint:file=/home/pinot/gc-pinot-broker.log:time,level,tags:filecount=5,filesize=100M -XX:NativeMemoryTracking=summary -XX:+AlwaysPreTouch -XX:+UseLargePages -XX:+CrashOnOutOfMemoryError -Djute.maxbuffer=4194304"


server:
  # replica
  replicaCount: 1
  # persistent disk
  persistence:
    enabled: true
    size: 2000Gi
  # normally, we want to run each pinot component in its own node pool. we need to create different node pools 
  nodeSelector:
    key: value
  # cpu and memory: the should be close to the resource available in the selected node pool
  resources:
    requests:
      cpu: 4
      memory: "16Gi"
    limits:
      cpu: 4
      memory: "16Gi"
  # jvm: notice that xmx and xms are usually set to be half of total memory
  jvmOpts: "-Xms8G -Xmx8G -XX:+UseG1GC -XX:MaxGCPauseMillis=200  -Xlog:gc+age*,safepoint:file=/home/pinot/gc-pinot-server.log:time,level,tags:filecount=5,filesize=100M -XX:NativeMemoryTracking=summary -XX:+AlwaysPreTouch -XX:+UseLargePages -XX:+CrashOnOutOfMemoryError -Djute.maxbuffer=4194304"

minion:
  # replica
  replicaCount: 1
  # persistent disk
  persistence:
    enabled: true
    size: 100Gi
  # normally, we want to run each pinot component in its own node pool. we need to create different node pools 
  nodeSelector:
    key: value
  # cpu and memory: the should be close to the resource available in the selected node pool
  resources:
    requests:
      cpu: 4
      memory: "8Gi"
    limits:
      cpu: 4
      memory: "8Gi"
  # jvm: notice that xmx and xms are usually set to be half of total memory
  jvmOpts: "-Xms4G -Xmx4G -XX:+UseG1GC -XX:MaxGCPauseMillis=200  -Xlog:gc+age*,safepoint:file=/home/pinot/gc-pinot-minion.log:time,level,tags:filecount=5,filesize=100M -XX:NativeMemoryTracking=summary -XX:+AlwaysPreTouch -XX:+UseLargePages -XX:+CrashOnOutOfMemoryError -Djute.maxbuffer=4194304"
```

